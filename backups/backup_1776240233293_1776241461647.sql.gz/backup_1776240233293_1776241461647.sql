-- LyraJS Database Backup
-- Database: elsass_simracing
-- Generated: 2026-04-15T08:24:21.647Z
-- Migration Version: 1776240233293

SET FOREIGN_KEY_CHECKS=0;

-- Table: migration_lock
DROP TABLE IF EXISTS `migration_lock`;
CREATE TABLE `migration_lock` (
  `id` int NOT NULL AUTO_INCREMENT,
  `locked_at` datetime NOT NULL,
  `hostname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `process_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table migration_lock
INSERT INTO `migration_lock` (`id`, `locked_at`, `hostname`, `process_id`) VALUES
  (1, '2026-04-15 06:24:21', 'PcDeJulien', 23771);

-- Table: migrations
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `version` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `executed_at` datetime NOT NULL,
  `execution_time` int DEFAULT NULL,
  `batch` int NOT NULL,
  `squashed` tinyint(1) DEFAULT '0',
  `backup_path` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`version`),
  KEY `idx_batch` (`batch`),
  KEY `idx_squashed` (`squashed`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS=1;
