-- LyraJS Database Backup
-- Database: elsass_simracing
-- Generated: 2026-04-15T08:29:07.261Z
-- Migration Version: 1776240233293

SET FOREIGN_KEY_CHECKS=0;

-- Table: migration_lock
DROP TABLE IF EXISTS `migration_lock`;
CREATE TABLE `migration_lock` (
  `id` int NOT NULL AUTO_INCREMENT,
  `locked_at` datetime NOT NULL,
  `hostname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `process_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table migration_lock
INSERT INTO `migration_lock` (`id`, `locked_at`, `hostname`, `process_id`) VALUES
  (2, '2026-04-15 06:29:07', 'PcDeJulien', 25169);

-- Table: migrations
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `version` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `executed_at` datetime NOT NULL,
  `execution_time` int DEFAULT NULL,
  `batch` int NOT NULL,
  `squashed` tinyint(1) DEFAULT '0',
  `backup_path` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`version`),
  KEY `idx_batch` (`batch`),
  KEY `idx_squashed` (`squashed`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS=1;
