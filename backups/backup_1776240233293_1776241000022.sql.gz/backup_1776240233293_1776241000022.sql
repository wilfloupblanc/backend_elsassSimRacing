-- LyraJS Database Backup
-- Database: elsass_simracing
-- Generated: 2026-04-15T08:16:40.022Z
-- Migration Version: 1776240233293

SET FOREIGN_KEY_CHECKS=0;

-- Table: availability
DROP TABLE IF EXISTS `availability`;
CREATE TABLE `availability` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `slots_total` tinyint DEFAULT NULL,
  `slots_remaining` tinyint DEFAULT NULL,
  `is_open` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: booking
DROP TABLE IF EXISTS `booking`;
CREATE TABLE `booking` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `price_paid` float DEFAULT NULL,
  `is_free_session` tinyint(1) DEFAULT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `availability_id` bigint DEFAULT NULL,
  `simulator_id` bigint DEFAULT NULL,
  `session_id` bigint DEFAULT NULL,
  `service_id` bigint DEFAULT NULL,
  `gift_voucher_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_booking_user_id` (`user_id`),
  KEY `fk_booking_availability_id` (`availability_id`),
  KEY `fk_booking_simulator_id` (`simulator_id`),
  KEY `fk_booking_session_id` (`session_id`),
  KEY `fk_booking_service_id` (`service_id`),
  KEY `fk_booking_gift_voucher_id` (`gift_voucher_id`),
  CONSTRAINT `fk_booking_availability_id` FOREIGN KEY (`availability_id`) REFERENCES `availability` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_booking_gift_voucher_id` FOREIGN KEY (`gift_voucher_id`) REFERENCES `giftvoucher` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_booking_service_id` FOREIGN KEY (`service_id`) REFERENCES `service` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_booking_session_id` FOREIGN KEY (`session_id`) REFERENCES `session` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_booking_simulator_id` FOREIGN KEY (`simulator_id`) REFERENCES `simulator` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_booking_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: giftvoucher
DROP TABLE IF EXISTS `giftvoucher`;
CREATE TABLE `giftvoucher` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `recipient_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recipient_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qr_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `used_at` timestamp NULL DEFAULT NULL,
  `stripe_payment_intent_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount_paid` float DEFAULT NULL,
  `purchaser_user_id` bigint DEFAULT NULL,
  `session_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_giftvoucher_qr_code` (`qr_code`),
  KEY `fk_giftvoucher_purchaser_user_id` (`purchaser_user_id`),
  KEY `fk_giftvoucher_session_id` (`session_id`),
  CONSTRAINT `fk_giftvoucher_purchaser_user_id` FOREIGN KEY (`purchaser_user_id`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_giftvoucher_session_id` FOREIGN KEY (`session_id`) REFERENCES `session` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: migration_lock
DROP TABLE IF EXISTS `migration_lock`;
CREATE TABLE `migration_lock` (
  `id` int NOT NULL AUTO_INCREMENT,
  `locked_at` datetime NOT NULL,
  `hostname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `process_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table migration_lock
INSERT INTO `migration_lock` (`id`, `locked_at`, `hostname`, `process_id`) VALUES
  (1, '2026-04-15 06:16:34', 'PcDeJulien', 21507);

-- Table: migrations
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `version` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `executed_at` datetime NOT NULL,
  `execution_time` int DEFAULT NULL,
  `batch` int NOT NULL,
  `squashed` tinyint(1) DEFAULT '0',
  `backup_path` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`version`),
  KEY `idx_batch` (`batch`),
  KEY `idx_squashed` (`squashed`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table migrations
INSERT INTO `migrations` (`version`, `executed_at`, `execution_time`, `batch`, `squashed`, `backup_path`) VALUES
  ('1775810302690', '2026-04-15 06:16:34', 286, 1, 0, NULL),
  ('1775810679105', '2026-04-15 06:16:35', 774, 1, 0, '/home/wilf_loupblanc/Bureau/backend_elsassSimRacing/backups/backup_1775810679105_1776240994734.sql.gz'),
  ('1775811072654', '2026-04-15 06:16:35', 109, 1, 0, NULL),
  ('1775811209458', '2026-04-15 06:16:35', 97, 1, 0, NULL),
  ('1775811355821', '2026-04-15 06:16:35', 96, 1, 0, NULL),
  ('1775811717477', '2026-04-15 06:16:36', 855, 1, 0, NULL),
  ('1775812082474', '2026-04-15 06:16:37', 514, 1, 0, NULL),
  ('1775812438937', '2026-04-15 06:16:39', 2504, 1, 0, NULL),
  ('1776068643727', '2026-04-15 06:16:39', 172, 1, 0, NULL),
  ('1776070330237', '2026-04-15 06:16:40', 2, 1, 0, NULL);

-- Table: scheduleoverride
DROP TABLE IF EXISTS `scheduleoverride`;
CREATE TABLE `scheduleoverride` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `is_open` tinyint(1) DEFAULT NULL,
  `description` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: scheduletemplate
DROP TABLE IF EXISTS `scheduletemplate`;
CREATE TABLE `scheduletemplate` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `day_of_week` tinyint DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `is_open` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: service
DROP TABLE IF EXISTS `service`;
CREATE TABLE `service` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: session
DROP TABLE IF EXISTS `session`;
CREATE TABLE `session` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `duration_minutes` tinyint DEFAULT NULL,
  `price_normal` float DEFAULT NULL,
  `price_member` float DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: simulator
DROP TABLE IF EXISTS `simulator`;
CREATE TABLE `simulator` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: subscription
DROP TABLE IF EXISTS `subscription`;
CREATE TABLE `subscription` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `stripe_subscription_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_period_start` timestamp NULL DEFAULT NULL,
  `current_period_end` timestamp NULL DEFAULT NULL,
  `monthly_free_session_used` tinyint(1) DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_subscription_stripe_subscription_id` (`stripe_subscription_id`),
  KEY `fk_subscription_user_id` (`user_id`),
  CONSTRAINT `fk_subscription_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: user
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_member` tinyint(1) DEFAULT NULL,
  `stripe_customer_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_user_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS=1;
